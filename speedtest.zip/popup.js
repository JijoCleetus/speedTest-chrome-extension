changeColor.addEventListener("click", async () => {
    document.querySelector('#speedValue').innerHTML = navigator.connection.downlink +'Mbps';
});
